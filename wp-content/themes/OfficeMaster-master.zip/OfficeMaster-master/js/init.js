jQuery(document).ready(function($){
    $('.all_filter_item').mixItUp();
});