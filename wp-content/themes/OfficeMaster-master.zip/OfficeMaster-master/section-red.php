    <section class="test1">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <img src="http://placehold.it/1500x500/f00" alt="">
                </div>
            </div>
        </div>
    </section>