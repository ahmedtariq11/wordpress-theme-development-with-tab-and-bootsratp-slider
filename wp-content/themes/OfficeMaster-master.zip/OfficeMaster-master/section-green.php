    <section class="test2">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <img src="http://placehold.it/1500x500/0f0" alt="">
                </div>
            </div>
        </div>
    </section>